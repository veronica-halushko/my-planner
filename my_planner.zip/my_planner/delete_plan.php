<?php
session_start();

// Sprawdzenie, czy użytkownik jest zalogowany
if (!isset($_SESSION['user_id'])) {
    header('Location: login.html');
    exit();
}

// Połączenie z bazą danych
$servername = "localhost";
$username = "root";
$password = "";
$database = "my_planner_db";

$conn = new mysqli($servername, $username, $password, $database);

// Sprawdzenie połączenia
if ($conn->connect_error) {
    die("Błąd połączenia z bazą danych: " . $conn->connect_error);
}

// Usuwanie planu
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $plan_id = $_POST['plan_id'];

    $stmt = $conn->prepare("DELETE FROM plans WHERE id = ? AND user_id = ?");
    $stmt->bind_param("ii", $plan_id, $_SESSION['user_id']);

    if ($stmt->execute()) {
        header("Location: view_plans.php?success=Plan%20usuniety");
        exit();
    } else {
        echo "Błąd podczas usuwania planu: " . $stmt->error;
    }

    $stmt->close();
}

$conn->close();
?>
