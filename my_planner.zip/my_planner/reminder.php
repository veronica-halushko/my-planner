<?php
session_start();

// Sprawdzenie, czy użytkownik jest zalogowany
if (!isset($_SESSION['user_id'])) {
    header('Location: login.html');
    exit();
}

// Połączenie z bazą danych
$servername = "localhost";
$username = "root"; // Domyślne dla XAMPP
$password = ""; // Domyślne dla XAMPP
$database = "my_planner_db"; // Nazwa bazy danych

$conn = new mysqli($servername, $username, $password, $database);

// Sprawdzenie połączenia
if ($conn->connect_error) {
    die("Błąd połączenia z bazą danych: " . $conn->connect_error);
}

$user_id = $_SESSION['user_id'];
$current_date = date("Y-m-d"); // Dzisiejsza data

// Pobieranie przypomnień na dzisiejszy dzień
$sql = "SELECT date, description FROM plans WHERE user_id = ? AND date = ? AND remind_me = 1";
$stmt = $conn->prepare($sql);
$stmt->bind_param("is", $user_id, $current_date);
$stmt->execute();
$result = $stmt->get_result();

$reminders = [];
if ($result && $result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $reminders[] = $row;
    }
}

$stmt->close();
$conn->close();
?>
<!DOCTYPE html>
<html lang="pl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Przypomnienia</title>
    <link rel="stylesheet" href="style1.css"> <!-- Wczytanie stylu z pliku CSS -->
</head>
<body>
    <div class="content-container">
        <h1>Twoje przypomnienia na dziś</h1>
        <?php if (!empty($reminders)): ?>
            <ul>
                <?php foreach ($reminders as $reminder): ?>
                    <li>
                        <strong><?php echo htmlspecialchars($reminder['date']); ?></strong>: 
                        <?php echo htmlspecialchars($reminder['description']); ?>
                    </li>
                <?php endforeach; ?>
            </ul>
        <?php else: ?>
            <p>Nie masz dzisiaj żadnych przypomnień.</p>
        <?php endif; ?>
        <a href="index.php"><button>Wróć do strony głównej</button></a>
    </div>
</body>
</html>
