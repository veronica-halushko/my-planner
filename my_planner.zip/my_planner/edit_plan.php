<?php
session_start();

// Sprawdzenie, czy użytkownik jest zalogowany
if (!isset($_SESSION['user_id'])) {
    header('Location: login.html');
    exit();
}

// Połączenie z bazą danych
$servername = "localhost";
$username = "root";
$password = "";
$database = "my_planner_db";

$conn = new mysqli($servername, $username, $password, $database);

// Sprawdzenie połączenia
if ($conn->connect_error) {
    die("Błąd połączenia z bazą danych: " . $conn->connect_error);
}

// Pobranie danych planu do edycji
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $plan_id = $_POST['plan_id'];

    $stmt = $conn->prepare("SELECT date, description FROM plans WHERE id = ? AND user_id = ?");
    $stmt->bind_param("ii", $plan_id, $_SESSION['user_id']);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $plan = $result->fetch_assoc();
    } else {
        echo "Nie znaleziono planu!";
        exit();
    }
}

?>
<!DOCTYPE html>
<html lang="pl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edytuj Plan</title>
    <link rel="stylesheet" href="style1.css">
</head>
<body>
    <h1>Edytuj plan</h1>
    <form action="update_plan.php" method="POST">
        <input type="hidden" name="plan_id" value="<?= $plan_id; ?>">
        <label for="date">Data:</label>
        <input type="date" id="date" name="date" value="<?= $plan['date']; ?>" required>
        <label for="description">Opis:</label>
        <textarea id="description" name="description" required><?= htmlspecialchars($plan['description']); ?></textarea>
        <button type="submit">Zapisz zmiany</button>
    </form>
    <a href="view_plans.php"><button>Wróć</button></a>
</body>
</html>

<?php
$stmt->close();
$conn->close();
?>
