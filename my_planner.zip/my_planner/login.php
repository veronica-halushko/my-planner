<?php
include 'db.php';
session_start();

ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = $_POST['username'];
    $password = $_POST['password'];

    $result = $conn->query("SELECT * FROM users WHERE username = '$username'");
    if ($result->num_rows > 0) {
        $user = $result->fetch_assoc();

        if (password_verify($password, $user['password'])) {
            // Ustaw sesję użytkownika
            $_SESSION['user_id'] = $user['id'];
            
            header('Location: index.php');
            exit();
        } else {
            echo "Nieprawidłowe hasło! Spróbuj ponownie ☺️";
        }
    } else {
        echo "Nie znaleziono użytkownika o takim loginie!";
    }
}
?>
