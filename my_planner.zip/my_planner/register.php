<?php
include 'db.php';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = $_POST['username'];
    $password = password_hash($_POST['password'], PASSWORD_BCRYPT);

    $result = $conn->query("SELECT * FROM users WHERE username = '$username'");
    if ($result->num_rows > 0) {
        echo "Użytkownik o podanym loginie już istnieje!";
    } else {
        $conn->query("INSERT INTO users (username, password) VALUES ('$username', '$password')");
        header('Location: login.html'); // Przekieruj do logowania po rejestracji
    }
}
?>
