<?php
$imagePath = "plan.jpg"; // Ścieżka względna do obrazu
session_start();
if (!isset($_SESSION['user_id'])) {
    header('Location: login.html'); 
    exit();
}

include 'db.php'; // Łączenie z bazą danych

$user_id = $_SESSION['user_id'];
$plans = [];

// Pobieranie planów z bazy danych
$sql = "SELECT id, date, title, description FROM plans WHERE user_id = $user_id ORDER BY date ASC";
$result = $conn->query($sql);

if ($result && $result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $plans[] = $row;
    }
}

$conn->close();
?>
<!DOCTYPE html>
<html lang="pl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sprawdź swoje plany</title>
    <link rel="stylesheet" href="style2.css">
</head>
<body>
    <div class="content-container">
        <!-- Lewa strona z listą planów -->
        <div class="plans-container">
            <h1>Twoje zaplanowane dni</h1>
            <?php if (!empty($plans)): ?>
                <ul>
                    <?php foreach ($plans as $plan): ?>
                        <li>
                            <strong><?php echo htmlspecialchars($plan['date']); ?></strong><br>
                            <em><?php echo htmlspecialchars($plan['title']); ?></em><br>
                            <?php echo htmlspecialchars($plan['description']); ?><br>
                            
                            <!-- Formularz edycji -->
                            <form action="edit_plan.php" method="POST" style="display: inline;">
                                <input type="hidden" name="plan_id" value="<?php echo $plan['id']; ?>">
                                <button type="submit">Edytuj</button>
                            </form>

                            <!-- Formularz usuwania -->
                            <form action="delete_plan.php" method="POST" style="display: inline;">
                                <input type="hidden" name="plan_id" value="<?php echo $plan['id']; ?>">
                                <button type="submit">Usuń</button>
                            </form>
                        </li>
                    <?php endforeach; ?>
                </ul>
            <?php else: ?>
                <p>Nie masz zapisanych żadnych planów.</p>
            <?php endif; ?>
            <a href="index.php"><button>Wróć do strony głównej</button></a>
        </div>

        <!-- Prawa strona z obrazem -->
        <div class="image-container">
            <img src="<?php echo $imagePath; ?>" alt="Obrazek planu">
        </div>
    </div>
</body>
</html>
