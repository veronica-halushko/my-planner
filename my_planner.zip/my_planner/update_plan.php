<?php
session_start();

// Sprawdzenie, czy użytkownik jest zalogowany
if (!isset($_SESSION['user_id'])) {
    header('Location: login.html');
    exit();
}

// Połączenie z bazą danych
$servername = "localhost";
$username = "root";
$password = "";
$database = "my_planner_db";

$conn = new mysqli($servername, $username, $password, $database);

// Sprawdzenie połączenia
if ($conn->connect_error) {
    die("Błąd połączenia z bazą danych: " . $conn->connect_error);
}

// Aktualizacja planu
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $plan_id = $_POST['plan_id'];
    $date = $_POST['date'];
    $description = $_POST['description'];

    $stmt = $conn->prepare("UPDATE plans SET date = ?, description = ? WHERE id = ? AND user_id = ?");
    $stmt->bind_param("ssii", $date, $description, $plan_id, $_SESSION['user_id']);

    if ($stmt->execute()) {
        header("Location: view_plans.php?success=Plan%20zaktualizowany");
        exit();
    } else {
        echo "Błąd podczas aktualizacji planu: " . $stmt->error;
    }

    $stmt->close();
}

$conn->close();
?>
