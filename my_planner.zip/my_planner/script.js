document.addEventListener("DOMContentLoaded", () => {
    const form = document.getElementById("plan-form");
    const plansList = document.getElementById("plans-list");

    // Funkcja do wypełniania selektorów daty
    function populateDateSelectors() {
        const daySelect = document.getElementById("day");
        const monthSelect = document.getElementById("month");
        const yearSelect = document.getElementById("year");

        // Wypełnij dni (1-31)
        for (let i = 1; i <= 31; i++) {
            const option = document.createElement("option");
            option.value = i;
            option.textContent = i < 10 ? "0" + i : i;
            daySelect.appendChild(option);
        }

        // Wypełnij miesiące (1-12)
        for (let i = 1; i <= 12; i++) {
            const option = document.createElement("option");
            option.value = i;
            option.textContent = i < 10 ? "0" + i : i;
            monthSelect.appendChild(option);
        }

        // Wypełnij lata (np. 2023-2033)
        const currentYear = new Date().getFullYear();
        for (let i = currentYear; i <= currentYear + 10; i++) {
            const option = document.createElement("option");
            option.value = i;
            option.textContent = i;
            yearSelect.appendChild(option);
        }
    }

    // Obsługa formularza
    form.addEventListener("submit", (e) => {
        e.preventDefault();

        const day = document.getElementById("day").value;
        const month = document.getElementById("month").value;
        const year = document.getElementById("year").value;
        const title = document.getElementById("plans").value;
        const description = document.getElementById("description").value;

        if (day && month && year && title) {
            const date = `${year}-${month.padStart(2, "0")}-${day.padStart(2, "0")}`;

            // Wysyłanie danych do process.php
            fetch("process.php?action=create", {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify({ date, title, description }),
            })
                .then((response) => response.json())
                .then((data) => {
                    if (data.success) {
                        alert("Plan zapisany!");
                        form.reset();
                        fetchPlans();
                    } else {
                        alert(data.error || "Wystąpił błąd!");
                    }
                })
                .catch((error) => console.error("Błąd:", error));
        } else {
            alert("Proszę wypełnić wszystkie pola!");
        }
    });

    // Pobieranie planów
    function fetchPlans() {
        fetch("process.php?action=read")
            .then((response) => response.json())
            .then((data) => {
                plansList.innerHTML = "";
                data.forEach((plan) => {
                    const li = document.createElement("li");
                    li.textContent = `${plan.date}: ${plan.title} - ${plan.description}`;
                    plansList.appendChild(li);
                });
            })
            .catch((error) => console.error("Błąd:", error));
    }

    // Wywołania na starcie
    populateDateSelectors();
    fetchPlans();
});
