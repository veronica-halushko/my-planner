<?php
// Rozpoczęcie sesji
session_start();

// Sprawdzenie, czy użytkownik jest zalogowany
if (!isset($_SESSION['user_id'])) {
    header('Location: login.html'); // Jeśli nie jest zalogowany, przekierowanie na stronę logowania
    exit();
}
?>
<!DOCTYPE html>
<html lang="pl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>My Planner</title>
    <link rel="stylesheet" href="style1.css">
    <script>
        document.addEventListener("DOMContentLoaded", () => {
            // Funkcja do wyświetlania aktualnego czasu
            function showCurrentTime() {
                const currentTime = new Date();
                const hours = currentTime.getHours().toString().padStart(2, '0');
                const minutes = currentTime.getMinutes().toString().padStart(2, '0');
                const seconds = currentTime.getSeconds().toString().padStart(2, '0');
                document.getElementById("current-time").innerHTML = "Aktualny czas: " + hours + ":" + minutes + ":" + seconds;
            }

            // Funkcja do wypełniania rozwijanych list dni, miesięcy i lat
            function populateDateSelectors() {
                const daySelect = document.getElementById("day");
                const monthSelect = document.getElementById("month");
                const yearSelect = document.getElementById("year");

                // Opcje dni (1-31)
                for (let i = 1; i <= 31; i++) {
                    const option = document.createElement("option");
                    option.value = i;
                    option.innerHTML = i < 10 ? "0" + i : i;
                    daySelect.appendChild(option);
                }

                // Opcje miesięcy (1-12)
                for (let i = 1; i <= 12; i++) {
                    const option = document.createElement("option");
                    option.value = i;
                    option.innerHTML = i < 10 ? "0" + i : i;
                    monthSelect.appendChild(option);
                }

                // Opcje lat 
                const currentYear = new Date().getFullYear();
                for (let i = currentYear; i >= currentYear - 10; i--) {
                    const option = document.createElement("option");
                    option.value = i;
                    option.innerHTML = i;
                    yearSelect.appendChild(option);
                }
            }

            // Wyświetlanie aktualnego czasu co sekundę
            setInterval(showCurrentTime, 1000);

            // Wypełnianie rozwijanych list
            populateDateSelectors();
        });
    </script>
</head>
<body>
    <h1>Witaj w "My Planner!"💖</h1>
    <h3>What's the plan for today?</h3>
    <div class="container">
        <!-- Formularz do przesyłania planów -->
        <form id="plan-form" action="proccess.php" method="POST">
            <div class="date-select">
                <select id="day" name="day" required>
                    <option value="">Wybierz dzień</option>
                    <!-- Opcje dni będą dodane przez JavaScript -->
                </select>
                <select id="month" name="month" required>
                    <option value="">Wybierz miesiąc</option>
                    <!-- Opcje miesięcy będą dodane przez JavaScript -->
                </select>
                <select id="year" name="year" required>
                    <option value="">Wybierz rok</option>
                    <!-- Opcje lat będą dodane przez JavaScript -->
                </select>
            </div>
            <textarea id="plans" name="plans" placeholder="Wpisz swoje plany na dzień" required></textarea>
            <div>
                <label>
                    <input type="checkbox" name="remind_me" value="1">
                    Przypomnij mi!☺️
                </label>
            </div>
            <button type="submit">Zapisz</button>
            <button type="button" onclick="document.getElementById('plans').value = ''">Wyczyść</button>
        </form>
    </div>
    <div id="current-time">Aktualny czas</div>
    <a href="view_plans.php"><button id="check-plans">Sprawdź swoje plany</button></a>
    <a href="reminder.php"><button>Przypomnienia</button></a>

</body>
</html>
