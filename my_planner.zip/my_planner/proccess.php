<?php
session_start();

// Sprawdzenie, czy użytkownik jest zalogowany
if (!isset($_SESSION['user_id'])) {
    header('Location: login.html');
    exit();
}

// Połączenie z bazą danych
$servername = "localhost";
$username = "root"; // Domyślne dla XAMPP
$password = ""; // Domyślne dla XAMPP
$database = "my_planner_db"; // Nazwa bazy danych

$conn = new mysqli($servername, $username, $password, $database);

// Sprawdzenie połączenia
if ($conn->connect_error) {
    die("Błąd połączenia z bazą danych: " . $conn->connect_error);
}

// Sprawdzenie, czy dane zostały przesłane metodą POST
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Pobranie danych z formularza
    $user_id = $_SESSION['user_id'];
    $day = $_POST['day'];
    $month = $_POST['month'];
    $year = $_POST['year'];
    $date = "$year-$month-$day"; // Tworzenie formatu daty YYYY-MM-DD
    $plans = $_POST['plans'];

    // Sprawdzenie, czy checkbox "Przypomnij mi" został zaznaczony
    $remind_me = isset($_POST['remind_me']) ? 1 : 0;

    // Walidacja danych 
    if (empty($plans)) {
        echo "Pole planów nie może być puste!";
        exit();
    }

    // Przygotowanie i wykonanie zapytania SQL
    $stmt = $conn->prepare("INSERT INTO plans (user_id, date, description, remind_me, created_at) VALUES (?, ?, ?, ?, NOW())");
    $stmt->bind_param("issi", $user_id, $date, $plans, $remind_me);

    if ($stmt->execute()) {
        // Sukces: przekierowanie lub komunikat
        header("Location: view_plans.php?success=1");
        exit();
    } else {
        echo "Błąd podczas zapisywania danych: " . $stmt->error;
    }

    $stmt->close();
}

$conn->close();
?>
